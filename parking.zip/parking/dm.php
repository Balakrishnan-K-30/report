<?php
// session_start();

// Set default theme if not set
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'light';
}

// Toggle theme when requested
if (isset($_GET['theme'])) {
    $_SESSION['theme'] = $_GET['theme'];
    exit();
}

$theme = $_SESSION['theme'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dark Mode Toggle</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            transition: 
                background 0.5s ease-in-out, 
                color 0.5s ease-in-out, 
                font-family 0.5s ease-in-out, 
                font-style 0.5s ease-in-out;
            text-align: center;
            padding: 50px;
        }

        /* Light Mode */
        body.light {
            background: #f0f8ff; /* Soft Blue */
            color: #222831; /* Dark Gray */
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
        }

        /* Dark Mode */
        body.dark {
            background: #1e1e2e; /* Deep Purple-Gray */
            color: #ffcc00; /* Golden Yellow */
            font-family: "Courier New", monospace;
            font-style: italic;
            font-weight: bold;
        }

        /* Toggle Switch */
        .switch-container {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 18px;
            margin-top: 20px;
        }

        .switch {
            position: relative;
            width: 60px;
            height: 30px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, #ffcc00, #ff6600);
            transition: 0.4s ease-in-out;
            border-radius: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 24px;
            width: 24px;
            left: 3px;
            bottom: 3px;
            background: white;
            transition: 0.4s ease-in-out;
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }

        input:checked + .slider {
            background: linear-gradient(45deg, #6610f2, #00d4ff);
        }

        input:checked + .slider:before {
            transform: translateX(30px);
        }

        /* Glow Effect */
        input:checked + .slider {
            box-shadow: 0 0 15px rgba(0, 212, 255, 0.5);
        }
    </style>
</head>
<body class="<?php echo $theme; ?>">

    <div class="switch-container">
        <span>🌞</span>
        <label class="switch">
            <input type="checkbox" id="themeToggle" <?php echo ($theme == 'dark') ? 'checked' : ''; ?>>
            <span class="slider"></span>
        </label>
        <span>🌙</span>
    </div>

    <p>Toggle the switch to change theme!</p>

    <script>
        document.getElementById('themeToggle').addEventListener('change', function () {
            let newTheme = this.checked ? 'dark' : 'light';
            
            // Change theme in PHP session via AJAX
            fetch('index.php?theme=' + newTheme).then(() => {
                document.body.className = newTheme;
            });
        });
    </script>

</body>
</html>
