<?php include 'db_connect.php' ?>
<?php 

if(isset($_GET['id'])){
	$qry = $conn->query("SELECT p.*,c.name as cname,l.location as lname FROM parked_list p INNER JOIN category c ON c.id = p.category_id INNER JOIN parking_locations l ON l.id = p.location_id WHERE p.id= ".$_GET['id']);
	foreach($qry->fetch_assoc() as $k => $v){
		$$k = $v;
	}
}
?>

<div class="mt-4 container-fluid animated-container">
	<div class="card animated-card">
		<div class="card-header">
			<span><b><?php echo isset($id) ? "Manage" : "New" ?> Vehicle</b></span>
		</div>
		<div class="card-body">
			<form action="sendmail.php" id="manage-vehicle"> 
				<input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
				<div class="col-lg-12">
					<!-- Vehicle Form Inputs -->
					<div class="form-group row animated-input">
						<div class="col-md-5">
							<label for="" class="control-label">Vehicle Category</label>
							<select name="category_id" id="category_id" class="custom-select select2">
								<option value=""></option>
								<?php
									$category = $conn->query("SELECT * FROM category ORDER BY name ASC");
									while($row= $category->fetch_assoc()):
								?>
								<option value="<?php echo $row['id'] ?>" <?php echo isset($category_id) && $category_id == $row['id'] ? 'selected' : '' ?> data-rate="<?php echo $row['rate'] ?>"><?php echo $row['name'] ?></option>
								<?php endwhile; ?>
							</select>
						</div>
						<div class="col-md-5">
							<label for="" class="control-label">Area</label>
							<select name="location_id" id="location_id" class="custom-select select2" required>
								<option value=""></option>
								<?php
									$category = $conn->query("SELECT * FROM parking_locations ORDER BY location ASC");
									while($row= $category->fetch_assoc()):
								?>
								<option value="<?php echo $row['id'] ?>" data-cid="<?php echo $row['category_id'] ?>" <?php echo isset($category_id) ? (isset($location_id) && $location_id == $row['id'] ? 'selected' : '') : "disabled" ?>><?php echo $row['location'] ?></option>
								<?php endwhile; ?>
							</select>
						</div>
					</div>
					<!-- Other Form Inputs -->
					<div class="row">
						<div class="col-md-12">
							<button name="send" class="btn-block float-right btn btn-sm btn-primary col-sm-3 animated-button">Save</button>
							<?php if(isset($id)) { ?>
								<button type="button" class="btn-block float-right btn btn-sm btn-danger col-sm-3 animated-button" onclick="checkoutVehicle(<?php echo $id; ?>)">Check-Out</button>
							<?php } ?>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

<script>
	function checkoutVehicle(vehicleId) {
		if(confirm("Are you sure you want to check out this vehicle?")) {
			window.location.href = "checkout.php?id=" + vehicleId;
		}
	}
</script>
