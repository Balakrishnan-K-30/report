<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check-In/Check-Out List</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
</head>
<body>

<div class="container mt-4">
    <div class="col-lg-12">
        <div class="card animated-card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Check-In/Check-Out List</h4>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered" id="vehicleTable">
                    <thead class="thead-dark">
                        <tr>
                            <th class="text-center">#</th>
                            <th>Date</th>
                            <th>Parking Reference No.</th>
                            <th>Owner</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        $qry = $conn->query("SELECT * FROM parked_list ORDER BY id DESC");
                        while($row = $qry->fetch_assoc()):
                        ?>  
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['date_created'])); ?></td>
                            <td><?php echo $row['ref_no']; ?></td>
                            <td><?php echo $row['owner']; ?></td>
                            <td>
                                <?php if($row['status'] == 1): ?>
                                    <span class="badge badge-warning">Checked-In</span>
                                <?php else: ?>
                                    <span class="badge badge-success">Checked-Out</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a class="btn btn-sm btn-outline-primary" href="index.php?page=view_parked_details&id=<?php echo $row['id']; ?>">View</a>
                                <a class="btn btn-sm btn-outline-danger delete_park" href="javascript:void(0)" data-id="<?php echo $row['id']; ?>">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Styling -->
<style>
    body {
        background: #f8f9fa;
    }
    .animated-card {
        opacity: 0;
        transform: scale(0.95);
        animation: fadeInScale 0.6s ease-in-out forwards;
    }
    @keyframes fadeInScale {
        from {
            opacity: 0;
            transform: scale(0.95);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
    .delete_park {
        transition: transform 0.2s ease-in-out;
    }
    .delete_park:hover {
        transform: scale(1.1);
    }
</style>

<!-- JavaScript -->
<script>
    $(document).ready(function() {
        $('#vehicleTable').DataTable();  // Initialize DataTables

        $('.delete_park').click(function() {
            var id = $(this).data('id');
            if (confirm("Are you sure you want to delete this entry?")) {
                delete_park(id);
            }
        });
    });

    function delete_park(id) {
        $.ajax({
            url: 'ajax.php?action=delete_vehicle',
            method: 'POST',
            data: { id: id },
            success: function(resp) {
                if (resp == 1) {
                    alert("Data successfully deleted!");
                    location.reload();
                } else {
                    alert("Error deleting data.");
                }
            }
        });
    }
</script>

</body>
</html>
