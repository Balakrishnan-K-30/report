<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Slot Reservation</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script>
        let bookedSlots = [];

        function bookSlot(slot) {
            if (bookedSlots.includes(slot)) {
                alert("This slot is already booked. Please choose another.");
                return;
            }
            bookedSlots.push(slot);
            document.getElementById(slot).classList.add("btn-danger");
            document.getElementById(slot).innerText = "Booked";
            alert("Slot " + slot + " booked successfully!");
        }
    </script>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Booking Slot Reservation</h2>
        <div class="row mt-4 text-center">
            <div class="col-md-4">
                <button id="slot1" class="btn btn-primary m-2" onclick="bookSlot('slot1')">09:00 - 10:00 AM</button>
            </div>
            <div class="col-md-4">
                <button id="slot2" class="btn btn-primary m-2" onclick="bookSlot('slot2')">10:00 - 11:00 AM</button>
            </div>
            <div class="col-md-4">
                <button id="slot3" class="btn btn-primary m-2" onclick="bookSlot('slot3')">11:00 - 12:00 PM</button>
            </div>
        </div>
        <div class="row mt-3 text-center">
            <div class="col-md-4">
                <button id="slot4" class="btn btn-primary m-2" onclick="bookSlot('slot4')">01:00 - 02:00 PM</button>
            </div>
            <div class="col-md-4">
                <button id="slot5" class="btn btn-primary m-2" onclick="bookSlot('slot5')">02:00 - 03:00 PM</button>
            </div>
            <div class="col-md-4">
                <button id="slot6" class="btn btn-primary m-2" onclick="bookSlot('slot6')">03:00 - 04:00 PM</button>
            </div>
        </div>
    </div>
</body>
</html>
