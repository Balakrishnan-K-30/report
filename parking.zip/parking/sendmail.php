<?php

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'vendors/autoload.php';

    $mail = new PHPMailer(true);

    if (isset($_POST['send'])) {
        // Check reCAPTCHA
        //  $_POST;
        if (isset($_POST['g-recaptcha-response'])) {
            $recaptchaResponse = $_POST['g-recaptcha-response'];
            $secretKey = '6Ld_YugqAAAAAEbn8xFmB_v3VOk5ysIzp5EyJy7b'; // Replace with your reCAPTCHA secret key

            // Verify reCAPTCHA
            if (verifyRecaptcha($recaptchaResponse, $secretKey)) {
                // reCAPTCHA verification successful, process the form data
                $category_id = $_POST['category_id'];
                $location_id = $_POST['location_id'];
                $vehicle_brand = $_POST['vehicle_brand'];
                $vehicle_registration = $_POST['vehicle_registration'];
                $owner = $_POST['owner'];
                $vehicle_description = $_POST['vehicle_description'];

                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'abhineshharish12@gail.com';
                    $mail->Password   = 'dkdfucvgjgfsmdfy';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port       = 465;

                    $mail->setFrom('abhineshharish12@gail.com ', 'Contact Us');
                    $mail->addAddress('mideennagoor@gmail.com');
                    $mail->addAddress('vishnustony@gmail.com');

                    $mail->isHTML(true);
                    $mail->Subject = 'Contact Form Submission - ' . $email;
                    $mail->Body  = '<p><b>category_id:&nbsp;</b>' . $category_id . '</p>';
                    $mail->Body .= '<p><b>location_id:&nbsp;</b>' . $location_id . '</p>';
                    $mail->Body .= '<p><b>vehicle_brand:&nbsp;</b>' . $vehicle_brand . '</p>';
                    $mail->Body .= '<p><b>vehicle_registration:&nbsp;</b>' . $vehicle_registration . '</p>';
                    $mail->Body .= '<p><b>owner:&nbsp;</b>' . $owner . '</p>';
                    $mail->Body .= '<p><b>vehicle_description:&nbsp;</b>' . $vehicle_description . '</p>';

                    $mail->send();
                    echo '<script>window.location.href="/"</script>';
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                // reCAPTCHA verification failed
                echo '<script>alert("Error in Google reCAPTCHA")</script>';
            }
        } else {
            // reCAPTCHA field not present
            echo '<script>alert("reCAPTCHA field is missing")</script>';
        }
    }

    // Function to verify Google reCAPTCHA
    function verifyRecaptcha($recaptchaResponse, $secretKey)
    {
        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $data = [
            'secret' => $secretKey,
            'response' => $recaptchaResponse,
        ];

        $options = [
            'http' => [
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data),
            ],
        ];

        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $resultJson = json_decode($result, true);

        return isset($resultJson['success']) && $resultJson['success'];
    }
    ?>